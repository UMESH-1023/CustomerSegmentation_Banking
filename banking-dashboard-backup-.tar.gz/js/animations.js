// Animation module for GSAP animations and scroll effects
const Animations = {
    // Initialize all animations
    init: () => {
        Animations.registerGSAP();
        Animations.setupScrollAnimations();
        Animations.setupHeroAnimations();
    },

    // Register GSAP plugins
    registerGSAP: () => {
        if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
            gsap.registerPlugin(ScrollTrigger);
        }
    },

    // Setup scroll-triggered animations
    setupScrollAnimations: () => {
        // Animate cards on scroll
        gsap.utils.toArray('.card, .step, .segment-card, .stat').forEach((el, i) => {
            gsap.fromTo(el,
                { y: 50, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 0.8,
                    delay: i * 0.1,
                    ease: 'power3.out',
                    scrollTrigger: {
                        trigger: el,
                        start: 'top 90%',
                        toggleActions: 'play none none none'
                    }
                }
            );
        });

        // Animate section titles
        gsap.utils.toArray('.section-title').forEach(title => {
            gsap.fromTo(title,
                { y: 30, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 0.8,
                    scrollTrigger: {
                        trigger: title,
                        start: 'top 90%',
                        toggleActions: 'play none none none'
                    }
                }
            );
        });

        // Animate insight content
        const insightContent = document.querySelector('.insight-text');
        if (insightContent) {
            gsap.fromTo(insightContent,
                { x: -50, opacity: 0 },
                {
                    x: 0,
                    opacity: 1,
                    duration: 0.8,
                    scrollTrigger: {
                        trigger: insightContent,
                        start: 'top 80%',
                        toggleActions: 'play none none none'
                    }
                }
            );
        }

        // Animate insight chart
        const insightChart = document.querySelector('.insight-chart');
        if (insightChart) {
            gsap.fromTo(insightChart,
                { x: 50, opacity: 0 },
                {
                    x: 0,
                    opacity: 1,
                    duration: 0.8,
                    scrollTrigger: {
                        trigger: insightChart,
                        start: 'top 80%',
                        toggleActions: 'play none none none'
                    }
                }
            );
        }
    },

    // Setup hero section animations
    setupHeroAnimations: () => {
        // Animate hero text elements
        gsap.to('.animate-text', {
            y: 0,
            opacity: 1,
            duration: 1,
            stagger: 0.2,
            ease: 'power3.out'
        });

        // Animate hero button
        gsap.to('.animate-btn', {
            y: 0,
            opacity: 1,
            duration: 1,
            delay: 0.6,
            ease: 'power3.out'
        });

        // Add floating animation to hero image
        gsap.to('.float', {
            y: 20,
            duration: 3,
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut'
        });
    }
};

// Export for use in other modules
window.Animations = Animations;
