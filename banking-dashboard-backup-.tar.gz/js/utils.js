// Utility functions and helpers
const Utils = {
    // Debounce function for performance
    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Email validation
    validateEmail: (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    },

    // Show success message for forms
    showSuccessMessage: (message, buttonElement) => {
        const originalText = buttonElement.innerHTML;
        buttonElement.innerHTML = '<i class="fas fa-check"></i>';
        buttonElement.style.backgroundColor = '#4caf50';

        setTimeout(() => {
            buttonElement.innerHTML = originalText;
            buttonElement.style.backgroundColor = '';
        }, 2000);
    },

    // Show error message
    showError: (input, message) => {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        input.classList.add('input-error');
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    },

    // Clear error message
    clearError: (input) => {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        input.classList.remove('input-error');
        if (errorElement) {
            errorElement.style.display = 'none';
        }
    },

    // Initialize utility functions (called from main.js)
    init: () => {
        console.log('🔧 Utils module initialized');
    }
};

// Export for use in other modules
window.Utils = Utils;
