// Navigation module for handling navigation functionality
const Navigation = {
    // Initialize navigation
    init: () => {
        Navigation.setupScrollEffects();
        Navigation.setupMobileMenu();
        Navigation.setupSmoothScrolling();
        Navigation.setupLoginLogoutButtons();
        Navigation.updateGetStartedButton();
    },

    // Setup navbar scroll effects
    setupScrollEffects: () => {
        const navbar = document.querySelector('.navbar');
        const backToTop = document.querySelector('.back-to-top');

        if (!navbar || !backToTop) return;

        const handleScroll = Utils.debounce(() => {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
                backToTop.classList.add('active');
            } else {
                navbar.classList.remove('scrolled');
                backToTop.classList.remove('active');
            }
        }, 10);

        window.addEventListener('scroll', handleScroll);
    },

    // Setup mobile menu toggle
    setupMobileMenu: () => {
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');

        if (!hamburger || !navLinks) return;

        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('active');
        });

        // Close mobile menu when clicking on nav links
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                hamburger.classList.remove('active');
            });
        });
    },

    // Setup smooth scrolling for anchor links
    setupSmoothScrolling: () => {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();

                const targetId = this.getAttribute('href');
                if (targetId === '#') return;

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
    },

    // Setup login/logout button functionality
    setupLoginLogoutButtons: () => {
        const loginBtn = document.getElementById('loginBtn');
        const logoutBtn = document.getElementById('logoutBtn');

        console.log('🔍 Navigation: Looking for login button...');
        console.log('Login button element:', loginBtn);
        console.log('Logout button element:', logoutBtn);

        if (loginBtn) {
            console.log('✅ Login button found, adding event listener');
            loginBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('🔗 Login button clicked via JS - redirecting to user dashboard...');
                window.location.href = 'user-dashboard.html';
            });
            console.log('✅ Login button event listener attached');
        } else {
            console.log('❌ Login button not found');
        }

        if (logoutBtn) {
            console.log('✅ Logout button found, adding event listener');
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('🔗 Logout button clicked');
                // Since no authentication, just redirect to home
                window.location.href = 'index.html';
            });
        } else {
            console.log('❌ Logout button not found');
        }
    },

    // Update Get Started button
    updateGetStartedButton: () => {
        const getStartedBtn = document.querySelector('.btn-primary');
        if (!getStartedBtn) {
            console.log('❌ Get Started button not found');
            return;
        }

        console.log('🔍 Navigation: Looking for Get Started button...');
        console.log('Get Started button element:', getStartedBtn);

        if (window.Auth && window.Auth.isAuthenticated && window.Auth.getCurrentUser) {
            const user = window.Auth.getCurrentUser();
            if (window.Auth.isAuthenticated()) {
                getStartedBtn.href = user.role === 'admin' ? 'admin-dashboard.html' : 'user-dashboard.html';
                getStartedBtn.textContent = 'Dashboard';
                console.log('✅ Get Started button updated for authenticated user');
            } else {
                getStartedBtn.href = 'user-dashboard.html';
                getStartedBtn.textContent = 'Get Started';
                console.log('✅ Get Started button updated for guest user');
            }
        } else {
            // Fallback if Auth module not loaded yet
            getStartedBtn.href = 'user-dashboard.html';
            getStartedBtn.textContent = 'Get Started';
            console.log('⚠️ Auth module not loaded, using fallback for Get Started button');
        }
    }
};

// Export for use in other modules
window.Navigation = Navigation;
