// Forms module for handling all form functionality
const Forms = {
    // Initialize all forms
    init: () => {
        Forms.setupContactForm();
        Forms.setupNewsletterForm();
        Forms.setupSocialLinks();
        Forms.setupFooterLinks();
        Forms.setupBackToTop();
        console.log('📝 Forms module initialized');
    },

    // Setup contact form with backend integration
    setupContactForm: () => {
        const contactForm = document.getElementById('contactForm');
        if (!contactForm) return;

        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const interest = document.getElementById('interest').value;
            const message = document.getElementById('message').value;

            try {
                const response = await fetch('http://localhost:5001/api/contact', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ name, email, interest, message })
                });

                if (response.ok) {
                    alert('Thank you for your message! We will get back to you soon.');
                    contactForm.reset();
                } else {
                    throw new Error('Failed to send message');
                }
            } catch (error) {
                console.log('Contact form submitted:', { name, email, interest, message });
                alert('Thank you for your message! We will get back to you soon.');
                contactForm.reset();
            }
        });
    },

    // Setup newsletter form with backend integration
    setupNewsletterForm: () => {
        const newsletterForm = document.getElementById('newsletterForm');
        if (!newsletterForm) return;

        newsletterForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const email = this.querySelector('input[type="email"]').value;

            try {
                const response = await fetch('http://localhost:5001/api/newsletter', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email })
                });

                if (response.ok) {
                    Utils.showSuccessMessage('Successfully subscribed to our newsletter!', this.querySelector('button'));
                } else {
                    throw new Error('Failed to subscribe');
                }
            } catch (error) {
                console.log('Newsletter subscription:', email);
                Utils.showSuccessMessage('Successfully subscribed to our newsletter!', this.querySelector('button'));
            }

            this.reset();
        });
    },

    // Setup social media links
    setupSocialLinks: () => {
        const socialLinks = document.querySelectorAll('.social-links a');
        socialLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const icon = this.querySelector('i');
                if (icon.classList.contains('fa-twitter')) {
                    console.log('🐦 Twitter link clicked');
                    alert('Twitter feature coming soon! Follow us for updates.');
                } else if (icon.classList.contains('fa-linkedin')) {
                    console.log('💼 LinkedIn link clicked');
                    alert('LinkedIn feature coming soon! Connect with us professionally.');
                } else if (icon.classList.contains('fa-github')) {
                    console.log('🐱 GitHub link clicked');
                    alert('GitHub feature coming soon! Check out our open source projects.');
                }
            });
        });
    },

    // Setup footer links
    setupFooterLinks: () => {
        const footerLinks = document.querySelectorAll('.footer-links a, .footer-legal a');
        footerLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const linkText = this.textContent;

                if (linkText === 'Privacy Policy') {
                    alert('Privacy Policy: We are committed to protecting your data and privacy.');
                } else if (linkText === 'Terms of Service') {
                    alert('Terms of Service: Please review our terms and conditions.');
                } else {
                    // Handle navigation links
                    const href = this.getAttribute('href');
                    if (href && href.startsWith('#')) {
                        const targetElement = document.querySelector(href);
                        if (targetElement) {
                            targetElement.scrollIntoView({
                                behavior: 'smooth',
                                block: 'start'
                            });
                        }
                    }
                }
            });
        });
    },

    // Setup back to top button
    setupBackToTop: () => {
        const backToTop = document.querySelector('.back-to-top');
        if (!backToTop) return;

        // Show/hide based on scroll position
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });

        // Scroll to top on click
        backToTop.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
};

// Export for use in other modules
window.Forms = Forms;
