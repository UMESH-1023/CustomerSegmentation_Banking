// Main application file - imports and initializes all modules
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 BankSeg Website Loading...');
    console.log('📍 Current URL:', window.location.href);

    // Initialize all modules
    try {
        // Always initialize utils first
        console.log('🔧 Initializing Utils module...');
        Utils.init && Utils.init();

        // Check if we're on a dashboard page
        if (window.location.pathname.includes('dashboard.html')) {
            console.log('📄 Dashboard page detected');
            // Initialize dashboard-specific modules
            if (window.Dashboard && window.Dashboard.init) {
                Dashboard.init();
                console.log('✅ Dashboard module initialized');
            } else {
                console.log('❌ Dashboard module not loaded yet');
            }
        } else {
            console.log('📄 Main website detected');
            // Initialize main website modules
            if (window.Navigation && window.Navigation.init) {
                Navigation.init();
                console.log('✅ Navigation module initialized');
            } else {
                console.log('❌ Navigation module not loaded yet');
            }

            if (window.Animations && window.Animations.init) {
                Animations.init();
                console.log('✅ Animations module initialized');
            } else {
                console.log('❌ Animations module not loaded yet');
            }

            if (window.Charts && window.Charts.init) {
                Charts.init();
                console.log('✅ Charts module initialized');
            } else {
                console.log('❌ Charts module not loaded yet');
            }

            if (window.Forms && window.Forms.init) {
                Forms.init();
                console.log('✅ Forms module initialized');
            } else {
                console.log('❌ Forms module not loaded yet');
            }

            console.log('✅ Main website modules initialized');
        }

        console.log('✅ All modules initialized successfully');
    } catch (error) {
        console.error('❌ Error initializing modules:', error);
    }
});
