// Login page module for handling authentication page functionality
const LoginPage = {
    // Initialize login page
    init: () => {
        LoginPage.setupTabSwitching();
        LoginPage.setupPasswordToggles();
        LoginPage.setupFormValidation();
        LoginPage.setupFormSubmissions();
        LoginPage.checkExistingAuth();
        console.log('🔐 Login page module initialized');
    },

    // Setup tab switching between login and signup
    setupTabSwitching: () => {
        const loginTab = document.getElementById('loginTab');
        const signupTab = document.getElementById('signupTab');
        const authTitle = document.getElementById('auth-title');
        const authSubtitle = document.getElementById('auth-subtitle');
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');

        if (!loginTab || !signupTab) return;

        loginTab.addEventListener('click', function() {
            loginTab.classList.add('active');
            signupTab.classList.remove('active');
            loginTab.style.color = '#4f46e5';
            loginTab.style.borderBottom = '2px solid #4f46e5';
            signupTab.style.color = '#64748b';
            signupTab.style.borderBottom = 'none';
            loginForm.style.display = 'block';
            signupForm.style.display = 'none';
            authTitle.textContent = 'Sign In';
            authSubtitle.textContent = 'Enter your credentials to access your account';
        });

        signupTab.addEventListener('click', function() {
            signupTab.classList.add('active');
            loginTab.classList.remove('active');
            signupTab.style.color = '#4f46e5';
            signupTab.style.borderBottom = '2px solid #4f46e5';
            loginTab.style.color = '#64748b';
            loginTab.style.borderBottom = 'none';
            signupForm.style.display = 'block';
            loginForm.style.display = 'none';
            authTitle.textContent = 'Create Account';
            authSubtitle.textContent = 'Join us to get personalized banking insights';
        });
    },

    // Setup password visibility toggles
    setupPasswordToggles: () => {
        const toggleLoginPassword = document.getElementById('toggleLoginPassword');
        const toggleSignupPassword = document.getElementById('toggleSignupPassword');
        const loginPassword = document.getElementById('login-password');
        const signupPassword = document.getElementById('signup-password');

        if (toggleLoginPassword && loginPassword) {
            toggleLoginPassword.addEventListener('click', function() {
                const type = loginPassword.getAttribute('type') === 'password' ? 'text' : 'password';
                loginPassword.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        }

        if (toggleSignupPassword && signupPassword) {
            toggleSignupPassword.addEventListener('click', function() {
                const type = signupPassword.getAttribute('type') === 'password' ? 'text' : 'password';
                signupPassword.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        }
    },

    // Setup form validation
    setupFormValidation: () => {
        const loginEmail = document.getElementById('login-email');
        const loginPassword = document.getElementById('login-password');
        const signupFirstName = document.getElementById('signup-firstname');
        const signupLastName = document.getElementById('signup-lastname');
        const signupEmail = document.getElementById('signup-email');
        const signupPassword = document.getElementById('signup-password');
        const signupConfirmPassword = document.getElementById('signup-confirm-password');

        // Login form validation
        if (loginEmail) {
            loginEmail.addEventListener('blur', function() {
                if (!this.value) {
                    Utils.showError(this, 'Email is required');
                } else if (!Utils.validateEmail(this.value)) {
                    Utils.showError(this, 'Please enter a valid email address');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        if (loginPassword) {
            loginPassword.addEventListener('blur', function() {
                if (!this.value) {
                    Utils.showError(this, 'Password is required');
                } else if (this.value.length < 8) {
                    Utils.showError(this, 'Password must be at least 8 characters long');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        // Signup form validation
        if (signupFirstName) {
            signupFirstName.addEventListener('blur', function() {
                if (!this.value.trim()) {
                    Utils.showError(this, 'First name is required');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        if (signupLastName) {
            signupLastName.addEventListener('blur', function() {
                if (!this.value.trim()) {
                    Utils.showError(this, 'Last name is required');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        if (signupEmail) {
            signupEmail.addEventListener('blur', function() {
                if (!this.value) {
                    Utils.showError(this, 'Email is required');
                } else if (!Utils.validateEmail(this.value)) {
                    Utils.showError(this, 'Please enter a valid email address');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        if (signupPassword) {
            signupPassword.addEventListener('blur', function() {
                if (!this.value) {
                    Utils.showError(this, 'Password is required');
                } else if (this.value.length < 8) {
                    Utils.showError(this, 'Password must be at least 8 characters long');
                } else {
                    Utils.clearError(this);
                }
            });
        }

        if (signupConfirmPassword) {
            signupConfirmPassword.addEventListener('blur', function() {
                if (!this.value) {
                    Utils.showError(this, 'Please confirm your password');
                } else if (this.value !== signupPassword.value) {
                    Utils.showError(this, 'Passwords do not match');
                } else {
                    Utils.clearError(this);
                }
            });
        }
    },

    // Setup form submissions
    setupFormSubmissions: () => {
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        const loginBtn = document.getElementById('loginBtn');
        const signupBtn = document.getElementById('signupBtn');

        // Login form submission
        if (loginForm) {
            loginForm.addEventListener('submit', async function(e) {
                e.preventDefault();

                const loginEmail = document.getElementById('login-email');
                const loginPassword = document.getElementById('login-password');
                const loginBtnText = loginBtn.querySelector('.btn-text');
                const loginBtnLoading = loginBtn.querySelector('.btn-loading');

                // Demo auto-fill
                if (!loginEmail.value) {
                    loginEmail.value = 'demo@bankseg.com';
                }
                if (!loginPassword.value) {
                    loginPassword.value = 'demo123';
                }

                // Show loading state
                if (loginBtnText && loginBtnLoading) {
                    loginBtnText.style.display = 'none';
                    loginBtnLoading.style.display = 'inline-block';
                    loginBtn.disabled = true;
                }

                try {
                    await LoginPage.handleLogin(loginEmail.value, loginPassword.value);
                } catch (error) {
                    console.error('Login error:', error);
                    alert('Login failed: ' + error.message);
                } finally {
                    if (loginBtnText && loginBtnLoading) {
                        loginBtnText.style.display = 'inline-block';
                        loginBtnLoading.style.display = 'none';
                        loginBtn.disabled = false;
                    }
                }
            });
        }

        // Signup form submission
        if (signupForm) {
            signupForm.addEventListener('submit', async function(e) {
                e.preventDefault();

                const signupFirstName = document.getElementById('signup-firstname');
                const signupLastName = document.getElementById('signup-lastname');
                const signupEmail = document.getElementById('signup-email');
                const signupPassword = document.getElementById('signup-password');
                const signupConfirmPassword = document.getElementById('signup-confirm-password');
                const signupBtnText = signupBtn.querySelector('.btn-text');
                const signupBtnLoading = signupBtn.querySelector('.btn-loading');

                // Validate required fields
                let isValid = true;

                if (!signupFirstName.value.trim()) {
                    Utils.showError(signupFirstName, 'First name is required');
                    isValid = false;
                }
                if (!signupLastName.value.trim()) {
                    Utils.showError(signupLastName, 'Last name is required');
                    isValid = false;
                }
                if (!signupEmail.value) {
                    Utils.showError(signupEmail, 'Email is required');
                    isValid = false;
                } else if (!Utils.validateEmail(signupEmail.value)) {
                    Utils.showError(signupEmail, 'Please enter a valid email address');
                    isValid = false;
                }
                if (!signupPassword.value) {
                    Utils.showError(signupPassword, 'Password is required');
                    isValid = false;
                } else if (signupPassword.value.length < 8) {
                    Utils.showError(signupPassword, 'Password must be at least 8 characters long');
                    isValid = false;
                }
                if (!signupConfirmPassword.value) {
                    Utils.showError(signupConfirmPassword, 'Please confirm your password');
                    isValid = false;
                } else if (signupConfirmPassword.value !== signupPassword.value) {
                    Utils.showError(signupConfirmPassword, 'Passwords do not match');
                    isValid = false;
                }

                if (!isValid) return;

                // Show loading state
                if (signupBtnText && signupBtnLoading) {
                    signupBtnText.style.display = 'none';
                    signupBtnLoading.style.display = 'inline-block';
                    signupBtn.disabled = true;
                }

                try {
                    await LoginPage.handleSignup(
                        signupFirstName.value.trim(),
                        signupLastName.value.trim(),
                        signupEmail.value,
                        signupPassword.value
                    );
                } catch (error) {
                    console.error('Signup error:', error);
                    alert('Signup failed: ' + error.message);
                } finally {
                    if (signupBtnText && signupBtnLoading) {
                        signupBtnText.style.display = 'inline-block';
                        signupBtnLoading.style.display = 'none';
                        signupBtn.disabled = false;
                    }
                }
            });
        }
    },

    // Handle login process
    handleLogin: (email, password) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    const userData = {
                        id: 'demo-user-123',
                        email: email,
                        role: 'customer',
                        name: 'Demo User'
                    };

                    localStorage.setItem('token', 'demo-token-12345');
                    localStorage.setItem('user', JSON.stringify(userData));

                    console.log('✅ Login successful:', userData);
                    window.location.href = 'index.html';
                    resolve(userData);
                } catch (error) {
                    reject(error);
                }
            }, 1000);
        });
    },

    // Handle signup process
    handleSignup: (firstName, lastName, email, password) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    const userData = {
                        id: 'new-user-' + Date.now(),
                        email: email,
                        role: 'customer',
                        name: `${firstName} ${lastName}`,
                        firstName: firstName,
                        lastName: lastName
                    };

                    localStorage.setItem('token', 'demo-token-12345');
                    localStorage.setItem('user', JSON.stringify(userData));

                    console.log('✅ Signup successful:', userData);
                    window.location.href = 'index.html';
                    resolve(userData);
                } catch (error) {
                    reject(error);
                }
            }, 1000);
        });
    },

    // Check if user is already authenticated
    checkExistingAuth: () => {
        const token = localStorage.getItem('token');
        if (token) {
            console.log('🔐 User already authenticated, redirecting to home...');
            window.location.href = 'index.html';
        }
    }
};

// Export for use in other modules
window.LoginPage = LoginPage;
