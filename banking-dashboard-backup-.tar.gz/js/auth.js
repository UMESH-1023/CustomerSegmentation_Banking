// Authentication module for handling login/logout functionality
const Auth = {
    // Check if user is authenticated
    isAuthenticated: () => {
        const token = localStorage.getItem('token');
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        return !!(token && user);
    },

    // Get current user
    getCurrentUser: () => {
        return JSON.parse(localStorage.getItem('user') || '{}');
    },

    // Get auth token
    getToken: () => {
        return localStorage.getItem('token');
    },

    // Login function
    login: (email, password) => {
        return new Promise((resolve, reject) => {
            // Demo authentication - in real app, this would be an API call
            setTimeout(() => {
                if (email && password) {
                    const userData = {
                        id: 'demo-user-' + Date.now(),
                        email: email,
                        role: 'customer',
                        name: email.split('@')[0].replace(/[^a-zA-Z0-9]/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
                    };

                    localStorage.setItem('token', 'demo-token-12345');
                    localStorage.setItem('user', JSON.stringify(userData));

                    resolve(userData);
                } else {
                    reject(new Error('Invalid credentials'));
                }
            }, 1000);
        });
    },

    // Signup function
    signup: (firstName, lastName, email, password) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (firstName && lastName && email && password) {
                    const userData = {
                        id: 'new-user-' + Date.now(),
                        email: email,
                        role: 'customer',
                        name: `${firstName} ${lastName}`,
                        firstName: firstName,
                        lastName: lastName
                    };

                    localStorage.setItem('token', 'demo-token-12345');
                    localStorage.setItem('user', JSON.stringify(userData));

                    resolve(userData);
                } else {
                    reject(new Error('All fields are required'));
                }
            }, 1000);
        });
    },

    // Logout function
    logout: () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    },

    // Update navigation based on auth status
    updateNavigation: () => {
        const loginBtn = document.getElementById('loginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeMessage = document.getElementById('welcome-message');
        const userNameElement = document.getElementById('user-name');
        const user = Auth.getCurrentUser();

        if (Auth.isAuthenticated()) {
            // User is logged in
            if (loginBtn) loginBtn.style.display = 'none';
            if (logoutBtn) {
                logoutBtn.style.display = 'inline-block';
                logoutBtn.textContent = `Logout (${user.name || user.email})`;
            }
            if (welcomeMessage && userNameElement) {
                welcomeMessage.style.display = 'block';
                userNameElement.textContent = user.name || user.email || 'User';
            }
        } else {
            // User is not logged in
            if (loginBtn) {
                loginBtn.style.display = 'inline-block';
                loginBtn.textContent = 'Login';
            }
            if (logoutBtn) logoutBtn.style.display = 'none';
            if (welcomeMessage) welcomeMessage.style.display = 'none';
        }
    }
};

// Export for use in other modules
window.Auth = Auth;
