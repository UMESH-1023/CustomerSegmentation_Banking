// Charts module for handling all chart/visualization functionality
const Charts = {
    // Initialize all charts
    init: () => {
        Charts.createBalanceChart();
    },

    // Create balance chart
    createBalanceChart: () => {
        const chartElement = document.getElementById('balanceChart');
        if (!chartElement) return;

        const ctx = chartElement.getContext('2d');

        if (typeof Chart !== 'undefined') {
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Young Savers', 'Established Professionals', 'Mortgage Seekers', 'Retired & Affluent'],
                    datasets: [{
                        label: 'Average Balance ($)',
                        data: [2500, 85000, 45000, 120000],
                        backgroundColor: [
                            'rgba(67, 97, 238, 0.7)',
                            'rgba(76, 201, 240, 0.7)',
                            'rgba(63, 55, 201, 0.7)',
                            'rgba(26, 26, 46, 0.7)'
                        ],
                        borderColor: [
                            'rgba(67, 97, 238, 1)',
                            'rgba(76, 201, 240, 1)',
                            'rgba(63, 55, 201, 1)',
                            'rgba(26, 26, 46, 1)'
                        ],
                        borderWidth: 1,
                        borderRadius: 8,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: {
                                family: '"Poppins", sans-serif',
                                size: 14
                            },
                            bodyFont: {
                                family: '"Poppins", sans-serif',
                                size: 14,
                                weight: '500'
                            },
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: false,
                            callbacks: {
                                label: function(context) {
                                    return `Average Balance: $${context.raw.toLocaleString()}`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    family: '"Poppins", sans-serif',
                                    size: 12
                                },
                                callback: function(value) {
                                    return '$' + value.toLocaleString();
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    family: '"Poppins", sans-serif',
                                    size: 12,
                                    weight: '500'
                                }
                            }
                        }
                    }
                }
            });
        }
    }
};

// Export for use in other modules
window.Charts = Charts;
