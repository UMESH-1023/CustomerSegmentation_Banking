// Dashboard module for handling dashboard-specific functionality
const Dashboard = {
    // Initialize dashboard
    init: () => {
        Dashboard.setupDashboard();
        Dashboard.initializeDashboardData();
        Dashboard.setupDashboardNavigation();
        console.log('🎛️ Dashboard module initialized');
    },

    // Setup dashboard functionality
    setupDashboard: () => {
        Dashboard.handleAuthentication();
        Dashboard.setupEventListeners();
    },

    // Handle user authentication
    handleAuthentication: () => {
        const token = localStorage.getItem('token');
        const userData = JSON.parse(localStorage.getItem('user') || '{}');

        if (!token || !userData.user) {
            console.log('🔐 No authentication found, redirecting to login');
            window.location.href = 'login.html';
            return;
        }

        console.log('✅ User authenticated:', userData.user.email);
    },

    // Setup dashboard event listeners
    setupEventListeners: () => {
        // Add any dashboard-specific event listeners here
        console.log('🎧 Dashboard event listeners setup');
    },

    // Initialize dashboard data
    initializeDashboardData: () => {
        const userData = JSON.parse(localStorage.getItem('user') || '{}');

        if (userData.user) {
            // Update user information display
            Dashboard.updateUserDisplay(userData.user);

            // Initialize banking patterns
            Dashboard.initializeBankingPatterns();

            // Initialize charts
            Dashboard.initializeCharts();

            // Load transactions
            Dashboard.loadTransactions();

            // Load dashboard data
            Dashboard.loadDashboardData();
        }
    },

    // Update user display elements
    updateUserDisplay: (user) => {
        // Update user name in sidebar
        const userNameEl = document.getElementById('userName');
        const userEmailEl = document.getElementById('userEmail');
        const userAvatarEl = document.getElementById('userAvatar');

        if (userNameEl) {
            userNameEl.textContent = user.email.split('@')[0];
        }

        if (userEmailEl) {
            userEmailEl.textContent = user.email;
        }

        if (userAvatarEl) {
            userAvatarEl.textContent = user.email.charAt(0).toUpperCase();
        }

        // Update user details section
        const userFullNameEl = document.getElementById('userFullName');
        const userContactEmailEl = document.getElementById('userContactEmail');
        const userContactPhoneEl = document.getElementById('userContactPhone');

        if (userFullNameEl) {
            userFullNameEl.textContent = user.email.split('@')[0] + ' Doe';
        }

        if (userContactEmailEl) {
            userContactEmailEl.textContent = user.email;
        }

        if (userContactPhoneEl) {
            userContactPhoneEl.textContent = '+1 (555) 123-4567';
        }
    },

    // Initialize banking patterns data
    initializeBankingPatterns: () => {
        // Update banking pattern values with sample data
        const avgDailySpendEl = document.getElementById('avgDailySpend');
        const topCategoryEl = document.getElementById('topCategory');
        const savingsRateEl = document.getElementById('savingsRate');
        const savingsGoalEl = document.getElementById('savingsGoal');
        const monthlyIncomeEl = document.getElementById('monthlyIncome');
        const incomeGrowthEl = document.getElementById('incomeGrowth');
        const riskScoreEl = document.getElementById('riskScore');
        const creditScoreEl = document.getElementById('creditScore');

        if (avgDailySpendEl) avgDailySpendEl.textContent = '$127';
        if (topCategoryEl) topCategoryEl.textContent = 'Food & Dining';
        if (savingsRateEl) savingsRateEl.textContent = '23%';
        if (savingsGoalEl) savingsGoalEl.textContent = '$5,000';
        if (monthlyIncomeEl) monthlyIncomeEl.textContent = '$4,500';
        if (incomeGrowthEl) incomeGrowthEl.textContent = '+8.2%';
        if (riskScoreEl) riskScoreEl.textContent = 'Low';
        if (creditScoreEl) creditScoreEl.textContent = '742';
    },

    // Initialize dashboard charts
    initializeCharts: () => {
        // Spending by Category Chart
        const spendingCtx = document.getElementById('spendingChart');
        if (spendingCtx && window.Chart) {
            new Chart(spendingCtx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Food & Dining', 'Transport', 'Entertainment', 'Shopping', 'Bills', 'Other'],
                    datasets: [{
                        data: [35, 25, 15, 10, 10, 5],
                        backgroundColor: [
                            '#ef4444', '#f59e0b', '#8b5cf6',
                            '#06b6d4', '#10b981', '#f97316'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }

        // Monthly Trend Chart
        const trendCtx = document.getElementById('trendChart');
        if (trendCtx && window.Chart) {
            new Chart(trendCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Spending',
                        data: [3200, 2800, 3500, 3100, 2900, 3241],
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value;
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }
    },

    // Load transactions data
    loadTransactions: async () => {
        const transactionList = document.getElementById('transactionList');
        const token = localStorage.getItem('token');

        if (!transactionList) return;

        try {
            const response = await fetch('http://localhost:5000/api/transactions', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const transactions = await response.json();
                Dashboard.displayTransactions(transactions);
            } else {
                console.error('Failed to load transactions, using sample data');
                Dashboard.showSampleTransactions();
            }
        } catch (error) {
            console.error('Error loading transactions:', error);
            Dashboard.showSampleTransactions();
        }
    },

    // Display transactions in the UI
    displayTransactions: (transactions) => {
        const transactionList = document.getElementById('transactionList');

        if (!transactionList) return;

        if (transactions.length === 0) {
            transactionList.innerHTML = '<div class="loading">No transactions found</div>';
            return;
        }

        transactionList.innerHTML = transactions.map(transaction => `
            <li class="transaction-item">
                <div class="transaction-icon ${transaction.type}">
                    <i class="fas fa-arrow-${transaction.type === 'credit' ? 'up' : 'down'}"></i>
                </div>
                <div class="transaction-details">
                    <div class="transaction-description">${transaction.description}</div>
                    <div class="transaction-meta">${new Date(transaction.date).toLocaleDateString()} • ${transaction.category}</div>
                </div>
                <div class="transaction-amount ${transaction.type}">
                    ${transaction.type === 'credit' ? '+' : '-'}$${transaction.amount.toFixed(2)}
                </div>
            </li>
        `).join('');
    },

    // Show sample transactions
    showSampleTransactions: () => {
        const sampleTransactions = [
            {
                type: 'debit',
                amount: 45.67,
                description: 'Starbucks Coffee',
                category: 'food',
                date: '2024-01-15',
                balance: 12300.33
            },
            {
                type: 'credit',
                amount: 2500.00,
                description: 'Salary Deposit',
                category: 'income',
                date: '2024-01-14',
                balance: 12346.00
            },
            {
                type: 'debit',
                amount: 89.32,
                description: 'Gas Station',
                category: 'transport',
                date: '2024-01-13',
                balance: 9846.00
            }
        ];
        Dashboard.displayTransactions(sampleTransactions);
    },

    // Load dashboard data
    loadDashboardData: async () => {
        const token = localStorage.getItem('token');

        try {
            const response = await fetch('http://localhost:5000/api/auth/me', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                Dashboard.updateDashboardStats(data);
            } else {
                console.error('Failed to load dashboard data');
                // Use fallback data
                Dashboard.updateDashboardStats({
                    profile: {
                        averageAccountBalance: 12345.67,
                        monthlyTransactionAmount: 47,
                        segment: 'Young Saver'
                    }
                });
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            // Use fallback data
            Dashboard.updateDashboardStats({
                profile: {
                    averageAccountBalance: 12345.67,
                    monthlyTransactionAmount: 47,
                    segment: 'Young Saver'
                }
            });
        }
    },

    // Update dashboard statistics
    updateDashboardStats: (data) => {
        if (data.profile) {
            const accountBalanceEl = document.getElementById('accountBalance');
            const monthlyTransactionsEl = document.getElementById('monthlyTransactions');
            const monthlySpendingEl = document.getElementById('monthlySpending');
            const userSegmentEl = document.getElementById('userSegment');

            if (accountBalanceEl) {
                accountBalanceEl.textContent = `$${data.profile.averageAccountBalance?.toLocaleString() || '0.00'}`;
            }

            if (monthlyTransactionsEl) {
                monthlyTransactionsEl.textContent = data.profile.monthlyTransactionAmount || '0';
            }

            if (userSegmentEl) {
                userSegmentEl.textContent = data.profile.segment || 'Not Segmented';
            }

            if (monthlySpendingEl) {
                const monthlySpending = data.profile.monthlyTransactionAmount || 0;
                monthlySpendingEl.textContent = `$${monthlySpending.toLocaleString()}`;
            }
        }
    },

    // Setup dashboard navigation
    setupDashboardNavigation: () => {
        // Add click handlers to sidebar menu items
        const sidebarLinks = document.querySelectorAll('.sidebar-menu a');
        sidebarLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();

                // Remove active class from all links
                sidebarLinks.forEach(l => l.classList.remove('active'));

                // Add active class to clicked link
                this.classList.add('active');

                const linkText = this.textContent.trim();
                console.log('Dashboard navigation clicked:', linkText);

                // Handle different navigation items
                if (linkText.includes('Dashboard')) {
                    Dashboard.showDashboard();
                } else if (linkText.includes('Transactions')) {
                    Dashboard.showTransactions();
                } else if (linkText.includes('Insights')) {
                    Dashboard.showInsights();
                } else if (linkText.includes('Profile')) {
                    Dashboard.showProfile();
                } else if (linkText.includes('Settings')) {
                    Dashboard.showSettings();
                }
            });
        });
    },

    // Navigation functions
    showDashboard: () => {
        console.log('Showing Dashboard');
        document.querySelector('.main-content').scrollIntoView({ behavior: 'smooth' });
    },

    showTransactions: () => {
        console.log('Showing Transactions');
        const transactionsSection = document.querySelector('.transactions-section');
        if (transactionsSection) {
            transactionsSection.scrollIntoView({ behavior: 'smooth' });
        }
    },

    showInsights: () => {
        console.log('Showing Insights');
        const chartsSection = document.querySelector('.charts-section');
        if (chartsSection) {
            chartsSection.scrollIntoView({ behavior: 'smooth' });
        }
    },

    showProfile: () => {
        alert('Profile management feature coming soon!');
    },

    showSettings: () => {
        alert('Settings feature coming soon!');
    },

    // Dashboard actions
    refreshData: () => {
        Dashboard.loadDashboardData();
        Dashboard.loadTransactions();
    },

    addTransaction: () => {
        Dashboard.openAddTransactionModal();
    },

    viewAllTransactions: () => {
        const transactionsSection = document.querySelector('.transactions-section');
        if (transactionsSection) {
            transactionsSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    },

    // Modal functionality for adding transactions
    openAddTransactionModal: () => {
        const modalHTML = `
            <div id="transactionModal" class="modal" style="display: block;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Add New Transaction</h3>
                        <span class="close" onclick="Dashboard.closeTransactionModal()">&times;</span>
                    </div>
                    <form id="transactionForm">
                        <div class="form-group">
                            <label for="transactionType">Type:</label>
                            <select id="transactionType" required>
                                <option value="debit">Expense</option>
                                <option value="credit">Income</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="transactionAmount">Amount:</label>
                            <input type="number" id="transactionAmount" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label for="transactionDescription">Description:</label>
                            <input type="text" id="transactionDescription" required>
                        </div>
                        <div class="form-group">
                            <label for="transactionCategory">Category:</label>
                            <select id="transactionCategory" required>
                                <option value="food">Food & Dining</option>
                                <option value="transport">Transport</option>
                                <option value="entertainment">Entertainment</option>
                                <option value="shopping">Shopping</option>
                                <option value="bills">Bills & Utilities</option>
                                <option value="healthcare">Healthcare</option>
                                <option value="income">Income</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="transactionDate">Date:</label>
                            <input type="date" id="transactionDate" required>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn btn-outline" onclick="Dashboard.closeTransactionModal()">Cancel</button>
                            <button type="submit" class="btn btn-primary">Add Transaction</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Set default date to today
        const dateInput = document.getElementById('transactionDate');
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }

        // Add event listener for form submission
        const form = document.getElementById('transactionForm');
        if (form) {
            form.addEventListener('submit', Dashboard.handleTransactionSubmit);
        }
    },

    closeTransactionModal: () => {
        const modal = document.getElementById('transactionModal');
        if (modal) {
            modal.remove();
        }
    },

    handleTransactionSubmit: async (e) => {
        e.preventDefault();

        const formData = {
            type: document.getElementById('transactionType').value,
            amount: parseFloat(document.getElementById('transactionAmount').value),
            description: document.getElementById('transactionDescription').value,
            category: document.getElementById('transactionCategory').value,
            date: document.getElementById('transactionDate').value
        };

        const token = localStorage.getItem('token');

        try {
            const response = await fetch('http://localhost:5000/api/transactions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                alert('Transaction added successfully!');
                Dashboard.closeTransactionModal();
                Dashboard.refreshData(); // Refresh the dashboard
            } else {
                throw new Error('Failed to add transaction');
            }
        } catch (error) {
            console.error('Error adding transaction:', error);
            alert('Failed to add transaction. Please try again.');
        }
    },

    // Additional dashboard functions
    refreshInsights: () => {
        alert('Refreshing financial insights...');
    },

    viewSpendingDetails: () => {
        alert('Detailed spending analysis coming soon!');
    },

    viewBudgetDetails: () => {
        alert('Budget management tools coming soon!');
    },

    exploreSavingsOptions: () => {
        alert('Savings account recommendations:\n\n• High-yield savings: 4.5% APY\n• Money market: 4.2% APY\n• CD options: 4.8% APY\n\nContact your financial advisor for personalized recommendations.');
    },

    viewGoalsProgress: () => {
        alert('Goal Progress Details:\n\nEmergency Fund: 100% Complete\nVacation Fund: 65% Complete\nNew Car: 0% Complete\n\nKeep up the great work!');
    },

    addNewGoal: () => {
        alert('Add New Financial Goal\n\nCreate a new savings goal with:\n• Target amount\n• Target date\n• Monthly contribution\n• Goal category\n\nFeature coming soon!');
    },

    logout: () => {
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = 'login.html';
        }
    }
};

// Export for use in other modules
window.Dashboard = Dashboard;
